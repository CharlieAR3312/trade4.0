"""Bitcoin accumulator bot package."""
