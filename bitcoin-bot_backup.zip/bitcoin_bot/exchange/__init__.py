"""Exchange adapters."""
