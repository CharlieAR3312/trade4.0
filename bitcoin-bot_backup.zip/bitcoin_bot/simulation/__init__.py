"""Simulation helpers."""
